<?php
/*
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'proj7703_restaurant');
*/
define('DB_HOST', 'localhost');
define('DB_USER', 'proj7703_restaur');
define('DB_PASS', '6*O,}dh+$nng');
define('DB_NAME', 'proj7703_restaurant');
//
